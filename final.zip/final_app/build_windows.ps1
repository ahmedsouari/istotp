<#
PowerShell build script to create a standalone Windows executable for Instaphone
This script will:
  1. Check for Python (and guide to install if missing)
  2. Create a virtual environment
  3. Install all dependencies (Flask, PyInstaller, etc.)
  4. Build a single-file .exe with all resources bundled

Usage (on Windows 10/11 PowerShell as Administrator):
  Open PowerShell in this folder and run:
    .\build_windows.ps1

Output: dist\instaphone.exe (ready to distribute)
#>

# Enable error handling
$ErrorActionPreference = "Stop"

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Instaphone Build Script for Windows 10/11" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check for Python and install if missing
Write-Host "[1/5] Checking for Python..." -ForegroundColor Yellow
$python = Get-Command python -ErrorAction SilentlyContinue

if (-not $python) {
    Write-Host "Python not found. Installing Python 3.12..." -ForegroundColor Yellow
    
    # Download Python 3.12 installer
    $pythonVersion = "3.12.1"
    $pythonUrl = "https://www.python.org/ftp/python/$pythonVersion/python-$pythonVersion-amd64.exe"
    $pythonInstaller = "$env:TEMP\python-$pythonVersion-amd64.exe"
    
    Write-Host "Downloading Python from: $pythonUrl" -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonInstaller -ErrorAction Stop
        Write-Host "✓ Download complete" -ForegroundColor Green
    } catch {
        Write-Host "Failed to download Python" -ForegroundColor Red
        Write-Host "Please download Python manually from: https://www.python.org/downloads/" -ForegroundColor Yellow
        Write-Host "Then re-run this script." -ForegroundColor Yellow
        exit 1
    }
    
    # Install Python silently with pip and add to PATH
    Write-Host "Installing Python (this may take a few minutes)..." -ForegroundColor Cyan
    $installArgs = "/quiet PrependPath=1 InstallAllUsers=1"
    try {
        Start-Process -FilePath $pythonInstaller -ArgumentList $installArgs -Wait -NoNewWindow
        Write-Host "✓ Python installed successfully" -ForegroundColor Green
    } catch {
        Write-Host "Failed to install Python" -ForegroundColor Red
        exit 1
    }
    
    # Refresh PATH environment variable
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    
    # Verify Python is now available
    $python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $python) {
        Write-Host "Python still not found after installation" -ForegroundColor Red
        Write-Host "Please restart PowerShell or your computer and try again." -ForegroundColor Yellow
        exit 1
    }
}

$pythonVersion = python --version
Write-Host "✓ Found: $pythonVersion" -ForegroundColor Green
Write-Host ""

# Step 2: Clean previous build
Write-Host "[2/5] Cleaning previous build artifacts..." -ForegroundColor Yellow
if (Test-Path ".venv") {
    Remove-Item -Recurse -Force ".venv" -ErrorAction SilentlyContinue
    Write-Host "✓ Removed old virtual environment" -ForegroundColor Green
}
if (Test-Path "build") {
    Remove-Item -Recurse -Force "build" -ErrorAction SilentlyContinue
    Write-Host "✓ Removed build folder" -ForegroundColor Green
}
if (Test-Path "dist") {
    Remove-Item -Recurse -Force "dist" -ErrorAction SilentlyContinue
    Write-Host "✓ Removed dist folder" -ForegroundColor Green
}
Write-Host ""

# Step 3: Create and activate virtual environment
Write-Host "[3/5] Setting up virtual environment..." -ForegroundColor Yellow
python -m venv .venv
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to create virtual environment"
    exit 1
}
Write-Host "✓ Virtual environment created" -ForegroundColor Green

# Activate virtual environment
& .\.venv\Scripts\Activate.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to activate virtual environment"
    exit 1
}
Write-Host "✓ Virtual environment activated" -ForegroundColor Green
Write-Host ""

# Step 4: Install dependencies
Write-Host "[4/5] Installing dependencies..." -ForegroundColor Yellow
Write-Host "Upgrading pip..." -ForegroundColor Cyan
pip install --upgrade pip --quiet

Write-Host "Installing Flask..." -ForegroundColor Cyan
pip install Flask --quiet
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to install Flask"
    exit 1
}
Write-Host "✓ Flask installed" -ForegroundColor Green

Write-Host "Installing PyInstaller..." -ForegroundColor Cyan
pip install pyinstaller --quiet
if ($LASTEXITCODE -ne 0) {
    Write-Error "Failed to install PyInstaller"
    exit 1
}
Write-Host "✓ PyInstaller installed" -ForegroundColor Green
Write-Host ""

# Step 5: Build executable
Write-Host "[5/5] Building standalone executable..." -ForegroundColor Yellow
Write-Host "This may take a few minutes..." -ForegroundColor Cyan
Write-Host ""

# PyInstaller command with all necessary options
# --onefile: Create single executable file
# --noconsole: Hide console window
# --add-data: Include templates and data directories
# --windowed: Treat as GUI application
# --name: Output executable name
pyinstaller `
    --onefile `
    --noconsole `
    --windowed `
    --add-data "templates;templates" `
    --add-data "data;data" `
    --name "instaphone" `
    --icon=None `
    app.py

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  Build Successful!" -ForegroundColor Green
    Write-Host "================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Executable location: dist\instaphone.exe" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "To run the application:" -ForegroundColor Cyan
    Write-Host "  1. Navigate to the dist folder" -ForegroundColor White
    Write-Host "  2. Double-click instaphone.exe" -ForegroundColor White
    Write-Host "  3. The app will open in your browser automatically" -ForegroundColor White
    Write-Host ""
    Write-Host "To distribute:" -ForegroundColor Cyan
    Write-Host "  Copy dist\instaphone.exe to any Windows 10/11 machine" -ForegroundColor White
    Write-Host "  No Python or dependencies needed on the target machine!" -ForegroundColor White
    Write-Host ""
    Write-Host "Default login credentials:" -ForegroundColor Cyan
    Write-Host "  Admin: admin / adminpass" -ForegroundColor White
    Write-Host "  Employee: employee / employeepass" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  Build Failed!" -ForegroundColor Red
    Write-Host "================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Check the error messages above for details." -ForegroundColor Yellow
    exit 1
}

