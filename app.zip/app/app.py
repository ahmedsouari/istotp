from flask import Flask, render_template, request, redirect, url_for, session, flash
import csv
import os
import sys
from datetime import datetime

# When bundled by PyInstaller, resources are extracted to a temp folder and
# accessible via sys._MEIPASS. Use that when available, otherwise use the
# directory of this script.
if getattr(sys, 'frozen', False):
    APP_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

STOCK_FILE = os.path.join(DATA_DIR, 'stock.csv')
SALES_FILE = os.path.join(DATA_DIR, 'sales.csv')
USERS_FILE = os.path.join(DATA_DIR, 'users.csv')

app = Flask(__name__, template_folder=os.path.join(APP_DIR, 'templates'))
app.secret_key = 'change_this_secret_in_production'


# --- CSV helpers ---
def read_csv(filepath):
    if not os.path.exists(filepath):
        return []
    with open(filepath, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return list(reader)


def write_csv(filepath, rows, fieldnames):
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def append_csv(filepath, row, fieldnames):
    exists = os.path.exists(filepath)
    with open(filepath, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            writer.writeheader()
        writer.writerow(row)


# --- Initialization: ensure CSVs exist with headers and a default admin and employee ---
def init_data():
    if not os.path.exists(USERS_FILE):
        users = [
            {'username': 'admin', 'role': 'admin', 'password': 'adminpass'},
            {'username': 'employee', 'role': 'employee', 'password': 'employeepass'},
        ]
        write_csv(USERS_FILE, users, fieldnames=['username', 'role', 'password'])

    if not os.path.exists(STOCK_FILE):
        stock = [
            {'id': '1', 'name': 'Example Phone A', 'quantity': '10', 'price': '299.99'},
            {'id': '2', 'name': 'Example Phone B', 'quantity': '5', 'price': '499.99'},
        ]
        write_csv(STOCK_FILE, stock, fieldnames=['id', 'name', 'quantity', 'price'])

    if not os.path.exists(SALES_FILE):
        write_csv(SALES_FILE, [], fieldnames=['id', 'stock_id', 'name', 'quantity', 'price', 'total', 'date'])


init_data()


# --- Auth helpers ---
def current_user():
    username = session.get('username')
    if not username:
        return None
    users = read_csv(USERS_FILE)
    for u in users:
        if u['username'] == username:
            return u
    return None


def require_login():
    if 'username' not in session:
        return False
    return True


# --- Routes ---
@app.route('/')
def home():
    if not require_login():
        return redirect(url_for('login'))
    user = current_user()
    return render_template('dashboard.html', user=user)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = read_csv(USERS_FILE)
        for u in users:
            if u['username'] == username and u['password'] == password:
                session['username'] = username
                flash('Logged in successfully.', 'success')
                return redirect(url_for('home'))
        flash('Invalid credentials.', 'danger')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out.', 'info')
    return redirect(url_for('login'))


@app.route('/stock', methods=['GET', 'POST'])
def stock():
    if not require_login():
        return redirect(url_for('login'))
    user = current_user()
    items = read_csv(STOCK_FILE)
    if request.method == 'POST':
        if user['role'] != 'admin':
            flash('Only admin can modify stock.', 'danger')
            return redirect(url_for('stock'))
        # Add new stock item
        name = request.form['name']
        quantity = request.form['quantity']
        price = request.form['price']
        next_id = str(int(items[-1]['id']) + 1) if items else '1'
        item = {'id': next_id, 'name': name, 'quantity': quantity, 'price': price}
        append_csv(STOCK_FILE, item, fieldnames=['id', 'name', 'quantity', 'price'])
        flash('Stock item added.', 'success')
        return redirect(url_for('stock'))
    return render_template('stock.html', user=user, items=items)


@app.route('/sell', methods=['GET', 'POST'])
def sell():
    if not require_login():
        return redirect(url_for('login'))
    user = current_user()
    items = read_csv(STOCK_FILE)
    if request.method == 'POST':
        stock_id = request.form['stock_id']
        qty = int(request.form['quantity'])
        # find item
        for it in items:
            if it['id'] == stock_id:
                available = int(it['quantity'])
                if qty > available:
                    flash('Not enough stock available.', 'danger')
                    return redirect(url_for('sell'))
                price = float(it['price'])
                total = price * qty
                # update stock quantity
                it['quantity'] = str(available - qty)
                write_csv(STOCK_FILE, items, fieldnames=['id', 'name', 'quantity', 'price'])
                # append sale
                sales = read_csv(SALES_FILE)
                sale_id = str(int(sales[-1]['id']) + 1) if sales else '1'
                sale = {
                    'id': sale_id,
                    'stock_id': it['id'],
                    'name': it['name'],
                    'quantity': str(qty),
                    'price': f"{price:.2f}",
                    'total': f"{total:.2f}",
                    'date': datetime.now().strftime('%Y-%m-%d'),
                }
                append_csv(SALES_FILE, sale, fieldnames=['id', 'stock_id', 'name', 'quantity', 'price', 'total', 'date'])
                flash(f"Sold {qty} x {it['name']} for ${total:.2f}", 'success')
                return redirect(url_for('sell'))
        flash('Item not found.', 'danger')
    return render_template('sell.html', user=user, items=items)


@app.route('/sales', methods=['GET'])
def sales():
    if not require_login():
        return redirect(url_for('login'))
    user = current_user()
    sales = read_csv(SALES_FILE)
    # optional filters
    date_from = request.args.get('from')
    date_to = request.args.get('to')
    month = request.args.get('month')  # format YYYY-MM
    filtered = []
    for s in sales:
        include = True
        if date_from and s['date'] < date_from:
            include = False
        if date_to and s['date'] > date_to:
            include = False
        if month and not s['date'].startswith(month):
            include = False
        if include:
            filtered.append(s)
    # compute totals
    total_amount = sum(float(s['total']) for s in filtered) if filtered else 0.0
    return render_template('sales.html', user=user, sales=filtered, total_amount=total_amount)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
