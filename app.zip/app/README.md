# Instaphone (simple Flask app)

This is a minimal Flask-based GUI (HTML) to manage a phone store called Instaphone.

Features:
- Stock management (add items, view stock) — admin only
- Record sales (employees and admin) — adjusts stock and logs sales
- Sales reporting by date range or month
- Simple user accounts stored in CSV (`data/users.csv`)

Default accounts:
- admin / adminpass (role: admin)
- employee / employeepass (role: employee)

Run (Windows 10/11):

1. Create a virtual environment (recommended):

```bash
python -m venv venv
venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the app:

```bash
python app.py
```

Open http://localhost:5000 in your browser.

Data files are stored in the `data/` folder as CSV files.
