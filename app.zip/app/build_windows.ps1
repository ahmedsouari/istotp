<#
PowerShell build script to create a single-file Windows executable
Usage (on Windows 10/11 PowerShell):
  Open PowerShell in this folder and run:
    .\build_windows.ps1

It will create a `dist\` folder with `app.exe` (named from the entry script).
#>
Set-StrictMode -Version Latest

Write-Host "Checking Python..."
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Error "Python not found. Install Python 3.8+ and re-run this script."
    exit 1
}

Write-Host "Creating virtual environment..."
python -m venv .venv
. .\.venv\Scripts\Activate.ps1

Write-Host "Installing build tools..."
pip install --upgrade pip
pip install pyinstaller

Write-Host "Building single-file executable with PyInstaller..."
# Include templates and data directories. Use ; separator for Windows.
pyinstaller --onefile --noconsole --add-data "templates;templates" --add-data "data;data" --name instaphone app.py

if ($LASTEXITCODE -eq 0) {
    Write-Host "Build complete. Find the exe in the dist\ folder: dist\instaphone.exe"
} else {
    Write-Error "Build failed. See PyInstaller output above."
}
